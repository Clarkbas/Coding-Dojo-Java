package EjerciciosBasicos;


public class Ejercicio04 {
	// Recorrer un Arreglo
	public static void main(String[] args) {
		int[] arr = {1,3,5,7,9,13};
		for(int i: arr) {
			System.out.print(i + ",");
		}
	}

}
