package EjerciciosBasicos;

public class Ejercicio02 {
	//Imprimir los Números Impares Entre 1 - 255
	public static void main(String[] args) {
		int num = 1;
		while(num <= 255){
			System.out.println(num + ",");
			num += 2;
		}


	}

}
