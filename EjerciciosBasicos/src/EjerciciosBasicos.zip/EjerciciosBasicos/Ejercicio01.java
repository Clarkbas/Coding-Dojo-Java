package EjerciciosBasicos;

public class Ejercicio01 {
	//Imprimir 1 - 255
	public static void main(String[] args) {
		
		for(int i = 1; i <= 255; i++) {
			System.out.println((i));
		}
	}

}
