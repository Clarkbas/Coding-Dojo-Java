package EjerciciosBasicos;

public class Ejercicio03 {
	//Imprimir la Suma
	public static void main(String[] args) {
		
	    int total = 0;
	    for(int i = 0; i<= 255; i++) {
	    	total += i;
			System.out.printf("Numero nuevo: %d  Suma: %d \n", i, total);
	    }
	}

}
