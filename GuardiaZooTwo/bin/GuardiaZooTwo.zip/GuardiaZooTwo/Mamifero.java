package GuardiaZooTwo;

public class Mamifero {
	
	
	//Atributos
    private int energyLevel;
    
    //Metodo Constructor, lo que hace es inicializar la clase
	public Mamifero (int energyLevel) {
		 

		 this.energyLevel = energyLevel;
		 
	 }
	
	// Metodo Constructor, lo que hace es inicializar la clase
	public Mamifero () {
		
	}
	

	public int getEnergyLevel() {
		return energyLevel;
	}

	public void setEnergyLevel(int energyLevel) {
		this.energyLevel = energyLevel;
	}
	
    public void fly() {
        System.out.println("El gorilla hace un sonido al despegar.");
        setEnergyLevel(getEnergyLevel() - 50);
        System.out.println("Nivel de energía después de volar: " + getEnergyLevel());
    }

}
